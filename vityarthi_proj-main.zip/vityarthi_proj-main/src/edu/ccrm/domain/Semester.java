package edu.ccrm.domain;

public enum Semester {
    SPRING,
    SUMMER,
    FALL
}
